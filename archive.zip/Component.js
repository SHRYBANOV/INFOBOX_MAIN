sap.ui.define(["sap/fe/core/AppComponent"],function(n){"use strict";return n.extend("infobox2main.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map